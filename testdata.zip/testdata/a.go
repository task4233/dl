package main

import (
	"fmt"
	"github.com/task4233/delog"
)

func main() {
	fmt.Println(message)
	delog.Println(message)
}
