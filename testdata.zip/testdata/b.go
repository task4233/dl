package main

import (
	"fmt"

	d "github.com/task4233/delog"
)

func main() {
	fmt.Println(message)
	d.Println(message)
}
