package main

import (
	"fmt"

	"github.com/task4233/dl/v2"
)

// main test
func main() {
	fmt.Println(message)
	// main test
	dl.Println(message)
}
