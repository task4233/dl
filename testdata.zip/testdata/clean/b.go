package main

import (
	"fmt"

	d "github.com/task4233/dl"
)

func main() {
	fmt.Println(message)
	d.Println(message)
}
