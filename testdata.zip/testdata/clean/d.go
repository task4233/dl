package main

import (
	d "github.com/task4233/dl"
)

func main() {
	d.Println(message)
}
