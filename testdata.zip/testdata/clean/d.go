package main

import (
	d "github.com/task4233/delog"
)

func main() {
	d.Println(message)
}
