package main

import (
	"fmt"

	"github.com/task4233/dl"
)

func main() {
	fmt.Println(message)
	dl.Println(message)
}
