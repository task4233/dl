package main

import d "github.com/task4233/dl/v2"

func main() {
	d.Println(message)
}
