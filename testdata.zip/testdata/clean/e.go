package main

import "github.com/task4233/dl"

func main() {
	dl.Println(message)
}
