package main

import "github.com/task4233/dl/v2"

func main() {
	dl.Println(message)
}
