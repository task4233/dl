package main

import "github.com/task4233/delog"

func main() {
	delog.Println(message)
}
